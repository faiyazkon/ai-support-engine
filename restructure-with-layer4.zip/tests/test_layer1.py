from fastapi.testclient import TestClient

from app.main import app

client = TestClient(app)
KEY = {"X-API-Key": "test-key-0123456789abcdef"}
GOOD = {
    "channel": "telegram",
    "user_id": "123456789",
    "profile_name": "রহিম",
    "text": "আমার ফোনটা ভাঙা এসেছে!!! আমি রহিম, নম্বর ০১৭১১২২৩৩৪৪। এখন কী করব?",
}


def test_health_needs_no_key():
    assert client.get("/health").json() == {"status": "ok"}


def test_good_message_passes():
    r = client.post("/message", json=GOOD, headers=KEY)
    assert r.status_code == 200
    assert r.json()["status"] == "answered"


def test_missing_key_is_401():
    assert client.post("/message", json=GOOD).status_code == 401


def test_wrong_key_is_401():
    assert client.post("/message", json=GOOD, headers={"X-API-Key": "nope"}).status_code == 401


def test_key_is_checked_before_the_body():
    # wrong key AND broken body: the key error wins, so strangers learn nothing about the shape
    r = client.post("/message", json={"bad": 1}, headers={"X-API-Key": "nope"})
    assert r.status_code == 401


def test_missing_field_is_422():
    body = {k: v for k, v in GOOD.items() if k != "user_id"}
    assert client.post("/message", json=body, headers=KEY).status_code == 422


def test_blank_text_is_422():
    for text in ["", "   ", "\n\t"]:
        assert client.post("/message", json={**GOOD, "text": text}, headers=KEY).status_code == 422


def test_unknown_channel_is_422():
    assert client.post("/message", json={**GOOD, "channel": "fax"}, headers=KEY).status_code == 422


def test_unknown_extra_field_is_422():
    assert client.post("/message", json={**GOOD, "tekst": "hi"}, headers=KEY).status_code == 422


def test_profile_name_is_optional():
    body = {k: v for k, v in GOOD.items() if k != "profile_name"}
    assert client.post("/message", json=body, headers=KEY).status_code == 200


def test_big_body_with_content_length_is_413():
    r = client.post("/message", content=b"x" * 20000, headers={**KEY, "Content-Type": "application/json"})
    assert r.status_code == 413


def test_big_body_without_content_length_is_413():
    def chunks():  # no Content-Length is sent, the body arrives in pieces
        for _ in range(20):
            yield b"x" * 1000

    r = client.post("/message", content=chunks(), headers={**KEY, "Content-Type": "application/json"})
    assert r.status_code == 413


def test_long_text_is_not_an_error_code_at_layer_1():
    # the 500-character rule belongs to layer 3, which gives a friendly reply instead of an error code
    r = client.post("/message", json={**GOOD, "text": "a" * 3000}, headers=KEY)
    assert r.status_code == 200
    assert r.json()["status"] == "refused"
