import re

from app.layers.identity import ID_LENGTH, make_user_key

SECRET = "test-id-secret-0123456789abcdef0123456789"


def test_same_person_gets_the_same_id():
    assert make_user_key("telegram", "123456789", SECRET) == make_user_key("telegram", "123456789", SECRET)


def test_different_people_get_different_ids():
    assert make_user_key("telegram", "123456789", SECRET) != make_user_key("telegram", "123456790", SECRET)


def test_same_number_on_another_channel_is_a_different_person():
    assert make_user_key("telegram", "1", SECRET) != make_user_key("web", "1", SECRET)


def test_different_secret_gives_a_different_id():
    assert make_user_key("telegram", "1", SECRET) != make_user_key("telegram", "1", SECRET + "x")


def test_id_is_16_lowercase_hex_characters():
    k = make_user_key("telegram", "123456789", SECRET)
    assert len(k) == ID_LENGTH == 16
    assert re.fullmatch(r"[0-9a-f]{16}", k)


def test_id_does_not_contain_the_real_user_id():
    assert "123456789" not in make_user_key("telegram", "123456789", SECRET)


def test_known_value_so_nobody_changes_the_method_by_accident():
    assert make_user_key("telegram", "123456789", SECRET) == "c82124f2006db050"


def test_works_with_bangla_text_ids():
    assert re.fullmatch(r"[0-9a-f]{16}", make_user_key("web", "রহিম-১২৩", SECRET))


def test_uses_the_secret_from_settings_by_default():
    assert make_user_key("telegram", "123456789") == "c82124f2006db050"
