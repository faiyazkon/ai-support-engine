from datetime import timedelta

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.database import storage
from app.database.connection import get_session_factory
from app.layers.identity import make_user_key
from app.main import app
from app.database.models import Message, User

client = TestClient(app)
KEY = {"X-API-Key": "test-key-0123456789abcdef"}


def rows(model):
    with get_session_factory()() as s:
        return list(s.scalars(select(model)))


# ---------- storage functions ----------

def test_first_message_creates_the_user():
    storage.begin_message("abc", "telegram", "hello", counted=True)
    (user,) = rows(User)
    assert (user.user_key, user.channel, user.message_count, user.strike_count) == ("abc", "telegram", 1, 0)
    assert user.first_seen == user.last_seen


def test_second_message_updates_the_same_user():
    storage.begin_message("abc", "telegram", "hello", counted=True)
    storage.begin_message("abc", "telegram", "again", counted=True)
    (user,) = rows(User)
    assert user.message_count == 2
    assert len(rows(Message)) == 2


def test_message_is_in_progress_until_finished():
    mid = storage.begin_message("abc", "telegram", "hello", counted=True)
    assert rows(Message)[0].status == "in_progress"
    storage.finish_message(mid, "answered", reply_text="hi", category="support_issue", llm_calls=1,
                           tokens_in=420, tokens_out=110, latency_ms=900, cited_sources='["returns_damaged"]')
    m = rows(Message)[0]
    assert (m.status, m.reply_text, m.category, m.llm_calls, m.tokens_in, m.tokens_out, m.latency_ms) == \
        ("answered", "hi", "support_issue", 1, 420, 110, 900)
    assert m.cited_sources == '["returns_damaged"]'


def test_refused_messages_do_not_keep_their_text():
    storage.begin_message("abc", "telegram", "secret words", counted=False)
    assert rows(Message)[0].original_text is None


def test_counted_messages_keep_their_text():
    storage.begin_message("abc", "telegram", "secret words", counted=True)
    assert rows(Message)[0].original_text == "secret words"


def test_count_counted_only_counts_passed_messages_since_the_time():
    now = storage.utcnow()
    for _ in range(3):
        storage.begin_message("abc", "telegram", "x", counted=True)
    storage.begin_message("abc", "telegram", "x", counted=False)
    storage.begin_message("other", "telegram", "x", counted=True)
    assert storage.count_counted("abc", now - timedelta(minutes=1)) == (3, 4)
    assert storage.count_counted("abc", now + timedelta(minutes=1)) == (0, 0)


def test_purge_erases_old_texts_but_keeps_the_rows():
    old = storage.begin_message("abc", "telegram", "old text", counted=True)
    storage.finish_message(old, "answered", reply_text="old reply", text_sent_to_llm="old sent")
    new = storage.begin_message("abc", "telegram", "new text", counted=True)
    storage.finish_message(new, "answered", reply_text="new reply")
    with get_session_factory()() as s, s.begin():
        s.get(Message, old).created_at = storage.utcnow() - timedelta(days=31)

    assert storage.purge_old_texts(30) == 1
    by_id = {m.id: m for m in rows(Message)}
    assert (by_id[old].original_text, by_id[old].reply_text, by_id[old].text_sent_to_llm) == (None, None, None)
    assert by_id[old].status == "answered"  # the row itself stays
    assert (by_id[new].original_text, by_id[new].reply_text) == ("new text", "new reply")


def test_purge_keeps_a_message_that_is_exactly_30_days_minus_a_minute_old():
    mid = storage.begin_message("abc", "telegram", "text", counted=True)
    with get_session_factory()() as s, s.begin():
        s.get(Message, mid).created_at = storage.utcnow() - timedelta(days=30) + timedelta(minutes=1)
    assert storage.purge_old_texts(30) == 0


# ---------- through the whole API ----------

def test_api_message_is_saved_with_the_secret_label_not_the_real_id():
    client.post("/message", json={"channel": "telegram", "user_id": "123456789", "text": "hello"}, headers=KEY)
    (user,) = rows(User)
    (message,) = rows(Message)
    assert user.user_key == make_user_key("telegram", "123456789")
    assert "123456789" not in user.user_key and "123456789" not in user.channel
    assert (message.status, message.counted, message.original_text) == ("answered", True, "hello")
    assert message.reply_text.startswith("[layers 1-4")
    assert message.latency_ms is not None


def test_api_refused_message_is_saved_without_its_text():
    client.post("/message", json={"channel": "test", "user_id": "1", "text": "a" * 501}, headers=KEY)
    (message,) = rows(Message)
    assert (message.status, message.reason, message.counted, message.original_text) == ("refused", "too_long", False, None)


def test_api_user_daily_limit_survives_because_it_is_in_the_database():
    key = make_user_key("test", "1")
    for _ in range(50):
        storage.begin_message(key, "test", "x", counted=True)
    body = client.post("/message", json={"channel": "test", "user_id": "1", "text": "hello"}, headers=KEY).json()
    assert body["status"] == "refused" and "tomorrow" in body["reply"]
    assert rows(Message)[-1].reason == "user_daily"


def test_api_global_daily_cap_needs_a_human():
    for i in range(2000):
        storage.begin_message(f"user{i % 100}", "test", "x", counted=True)
    body = client.post("/message", json={"channel": "test", "user_id": "1", "text": "hello"}, headers=KEY).json()
    assert body["status"] == "needs_human"


def test_server_startup_creates_tables_and_purges_without_error():
    with TestClient(app) as started:  # entering the block runs the startup code
        assert started.get("/health").json() == {"status": "ok"}
