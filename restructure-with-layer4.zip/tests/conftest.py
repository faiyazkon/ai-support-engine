import os

# Must be set before app.main is imported, because the app reads its settings at import time.
os.environ["API_KEY"] = "test-key-0123456789abcdef"
os.environ["MAX_BODY_BYTES"] = "10000"
os.environ["ID_SECRET"] = "test-id-secret-0123456789abcdef0123456789"
os.environ["DATABASE_URL"] = "sqlite://"  # an empty database in memory, so tests never touch your real data
os.environ["RETENTION_DAYS"] = "30"

import pytest


@pytest.fixture(autouse=True)
def fresh_state():
    # every test starts with an empty database and empty counters, so tests can't affect each other
    from app.database.connection import get_engine, get_session_factory, init_db
    from app.layers.limits import get_limiter

    get_limiter.cache_clear()
    get_session_factory.cache_clear()
    get_engine.cache_clear()
    init_db()
    yield
