from datetime import datetime, timezone

from fastapi.testclient import TestClient

from app.layers.limits import DHAKA, Limiter, dhaka_day_start_utc
from app.main import app

client = TestClient(app)
KEY = {"X-API-Key": "test-key-0123456789abcdef"}


def msg(text="hello", user="1"):
    return {"channel": "test", "user_id": user, "text": text}


class FakeClock:
    def __init__(self, start=1_000_000.0):
        self.t = start

    def __call__(self):
        return self.t


def make(clock, max_chars=500, per_minute=5, per_user_day=50, global_day=2000, daily=lambda user, since: (0, 0)):
    return Limiter(max_chars, per_minute, per_user_day, global_day, daily_counts=daily, clock=clock)


# ---------- the limiter alone, with a fake clock and a fake database ----------

def test_normal_message_is_allowed():
    assert make(FakeClock()).check("u1", "hello").allowed


def test_exactly_500_characters_is_allowed_and_501_is_not():
    lim = make(FakeClock())
    assert lim.check("u1", "a" * 500).allowed
    r = lim.check("u1", "a" * 501)
    assert (r.allowed, r.reason) == (False, "too_long")


def test_bangla_text_is_counted_in_characters():
    assert make(FakeClock()).check("u1", "আ" * 500).allowed


def test_sixth_message_in_a_minute_is_blocked():
    lim = make(FakeClock())
    for _ in range(5):
        assert lim.check("u1", "hi").allowed
    r = lim.check("u1", "hi")
    assert (r.allowed, r.reason) == (False, "rate")


def test_rate_limit_is_per_person():
    lim = make(FakeClock())
    for _ in range(6):
        lim.check("u1", "hi")
    assert lim.check("u2", "hi").allowed


def test_person_is_allowed_again_after_a_minute():
    clock = FakeClock()
    lim = make(clock)
    for _ in range(6):
        lim.check("u1", "hi")
    clock.t += 61
    assert lim.check("u1", "hi").allowed


def test_hammering_keeps_you_blocked():
    clock = FakeClock()
    lim = make(clock)
    for _ in range(6):
        lim.check("u1", "hi")
    for _ in range(12):  # keeps trying every 10 seconds for two minutes
        clock.t += 10
        assert lim.check("u1", "hi").reason == "rate"


def test_user_daily_limit():
    lim = make(FakeClock(), per_user_day=3, daily=lambda user, since: (3, 3))
    r = lim.check("u1", "hi")
    assert (r.allowed, r.reason) == (False, "user_daily")


def test_under_the_user_daily_limit_is_allowed():
    assert make(FakeClock(), per_user_day=3, daily=lambda user, since: (2, 2)).check("u1", "hi").allowed


def test_global_daily_limit():
    lim = make(FakeClock(), global_day=3, daily=lambda user, since: (0, 3))
    r = lim.check("u1", "hi")
    assert (r.allowed, r.reason) == (False, "global_daily")


def test_the_day_starts_at_midnight_dhaka_time():
    # Dhaka is UTC+6, so Dhaka midnight is 18:00 UTC the evening before
    now = datetime(2026, 11, 19, 15, 30, tzinfo=DHAKA).timestamp()
    assert dhaka_day_start_utc(now) == datetime(2026, 11, 18, 18, 0)
    just_before_midnight = datetime(2026, 11, 19, 23, 59, tzinfo=DHAKA).timestamp()
    assert dhaka_day_start_utc(just_before_midnight) == datetime(2026, 11, 18, 18, 0)
    just_after_midnight = datetime(2026, 11, 20, 0, 1, tzinfo=DHAKA).timestamp()
    assert dhaka_day_start_utc(just_after_midnight) == datetime(2026, 11, 19, 18, 0)


def test_the_limiter_asks_the_database_about_todays_window():
    asked = []
    now = datetime(2026, 11, 19, 15, 30, tzinfo=DHAKA).timestamp()
    lim = make(FakeClock(now), daily=lambda user, since: asked.append((user, since)) or (0, 0))
    lim.check("u1", "hi")
    assert asked == [("u1", datetime(2026, 11, 18, 18, 0))]


# ---------- through the whole API ----------

def test_api_long_message_gets_a_fixed_bilingual_reply():
    body = client.post("/message", json=msg("a" * 501), headers=KEY).json()
    assert body["status"] == "refused"
    assert "500" in body["reply"] and "অক্ষর" in body["reply"]


def test_api_sixth_message_in_a_minute_is_refused():
    statuses = [client.post("/message", json=msg(), headers=KEY).json()["status"] for _ in range(6)]
    assert statuses == ["answered"] * 5 + ["refused"]


def test_api_two_people_do_not_share_a_limit():
    for _ in range(6):
        client.post("/message", json=msg(user="1"), headers=KEY)
    assert client.post("/message", json=msg(user="2"), headers=KEY).json()["status"] == "answered"
